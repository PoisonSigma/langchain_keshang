def invoke(msg:str):
    return f"invoke执行${msg}"
def stream():
    yield "你"
    yield "好"
    yield "啊"
    yield "我"
    yield "叫"
    yield "赛利亚"
    yield "把你的手机给我"

